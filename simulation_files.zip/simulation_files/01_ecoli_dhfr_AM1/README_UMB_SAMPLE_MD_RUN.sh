#!/bin/bash
#

# Check if the required arguments are provided
if [ $# -ne 3 ]; then
  echo "Usage: $0 <CONDA_ENV_NAME> <SQM_INSTALL_DIR> <CHARMM_DIR>"
  exit 1
fi

# SET BY USER: NECESSARY DIRECTORY PATHS
export CONDA_ENV_NAME=$1
export SQM_INSTALL_DIR=$2
export CHARMM_DIR=$3
# SET BY USER: ASSIGN NUMBER OF PROCESSORS 
export OMP_NUM_THREADS=1
charmm_nproc=1

#==============================================================

# SETTING UP CONDA ENVIRONMENT (FOR QMHub AND helPME)
echo "Activating Conda environment: $CONDA_ENV_NAME"
conda activate $CONDA_ENV_NAME
if [ $? -ne 0 ]; then
  echo "Error: Failed to activate Conda environment: $CONDA_ENV_NAME"
  exit 1
fi


# SETTING 'SQM' (AMBERTOOLS) TO PATH
echo "Setting up SQM (AmberTools) from: $SQM_INSTALL_DIR"
source $SQM_INSTALL_DIR/amber.sh
if [ $? -ne 0 ]; then
  echo "Error: Failed to source amber.sh from: $SQM_INSTALL_DIR"
  exit 1
fi


# SETTING MODIFIED CHARMM LOCATION AND INPUT FILES
charmm=$CHARMM_DIR/charmm_install_dir/bin/charmm
if [ ! -f "$charmm" ]; then
  echo "Error: CHARMM program not found at $charmm"
  exit 1
fi


equi_prefix=step4.0_equilibration
qmpr_prefix=step4.1_qmmmprep
prod_prefix=step5_production_nvt
prod_step=step5
umb_window=window
qm_package=qmhub

#==============================================================

# MINIMIZATION AND EQUILIBRATION MD

mpirun -np 4 ${charmm} < ${equi_prefix}.inp > ${equi_prefix}.out

#==============================================================

# QM/MM INPUT PREPERATION 

${charmm} < ${qmpr_prefix}.inp > ${qmpr_prefix}.out

#==============================================================

# QM/MM MD WITH UMBRELLA SAMPLING (US)

cntmax=6 # 'cntmax' number of chunks per window (eg: 6x10ps)
win=1 # starting US window 
winmax=41 # finishing US window

for ((i=$win;i<=$winmax;i++)); do
    cnt=1  # restart control
    while [ $cnt -le $cntmax ]; do
        pcnt=$(( cnt - 1 ))
        istep=${prod_step}_${umb_window}_${i}_${cnt}
        pstep=${prod_step}_${umb_window}_${i}_${pcnt}
        if [ ${cnt} -eq 1 ]; then
            pstep=${equi_prefix}
        fi

        ${charmm} win=${i} cnt=${cnt} cntmax=${cntmax} qm_package=${qm_package} < ${prod_prefix}.inp > ${istep}.out
        cnt=$(( cnt + 1 ))
    done
done

#==============================================================

